# DandeliTourDestination — Royal Red & Gold Resort Website

A responsive, multi-section resort discovery and enquiry website for DandeliTourDestination, Dandeli.

## Run locally
Open `index.html` in a modern browser, or serve this folder with any static web server.

## Included experience
- Royal burgundy, deep red, antique gold and warm ivory visual system.
- Cinematic hero section and editorial resort storytelling layout.
- Responsive desktop, tablet and mobile navigation/layouts.
- Large call-to-action buttons with hover, press and touch ripple feedback.
- Scroll-triggered reveal animations and reading progress indicator.
- Resort cards populated from `js/data.js`, detail modal and WhatsApp enquiry links.
- Booking and contact forms that prepare WhatsApp enquiries.
- Accessible reduced-motion support and keyboard dismissal for the mobile menu/modal.

## Customise
- Resort/property content: `js/data.js`
- Phone number and WhatsApp destination: `js/app.js`
- Main page content: `index.html`
- Design tokens, responsive rules and animations: `css/style.css`

The site uses Google Fonts, Lucide icons and externally hosted Unsplash photography, so those assets require an internet connection.
